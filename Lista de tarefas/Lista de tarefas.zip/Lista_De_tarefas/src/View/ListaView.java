package View;

import Model.ListaModel;

public class ListaView {
	
	public void mostrarStatusTarefa(ListaModel tarefa) {
		// TODO Auto-generated method stub
		
	}

	public void mostrarErro(String string) {
		// TODO Auto-generated method stub
		
	}

}
