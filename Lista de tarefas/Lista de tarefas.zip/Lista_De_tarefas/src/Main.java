import java.util.Scanner;
import Controller.ListaController;

public class Main {
	ListaController listacontroller = new ListaController();
	Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		
		ListaController listaController = new ListaController();
		Scanner scanner = new Scanner(System.in);
		
		int opcao = -1;
		while (opcao != 0) {
			System.out.println("==== Lista De Tarefas ====");
			System.out.println("1. Adicionar Tarefa");
			System.out.println("2. Exibir lista de pa�ses");
			System.out.println("3. Limpar Lista");
			opcao = scanner.nextInt();
			
			switch (opcao) {
			case 1:
				System.out.println("adicionar tarefa");
				scanner.nextLine();
				String lista = scanner.nextLine();
				String status = scanner.nextLine();
				listaController.adicionartarefa(lista, status);
				break;
			}
			scanner.close();
		}
	}
}
