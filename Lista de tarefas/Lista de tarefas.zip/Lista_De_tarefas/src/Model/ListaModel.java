package Model;
import Controller.ListaController;
import View.ListaView;

public class ListaModel {
	
	private String lista;
	private String status;
	
	public ListaModel(String lista, String status){
		this.lista = lista;
		this.status = status;
		
	}

	public String getLista() {
		return lista;
	}

	public void setLista(String lista) {
		this.lista = lista;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}


