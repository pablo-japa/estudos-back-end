package Controller;

import Model.ListaModel;
import View.ListaView;
import java.util.List;
import java.util.ArrayList;

//acima importei v�rias utilidades da biblioteca java


public class ListaController {
//criei duas v�riaveis privadas, a listaView existe em outro packged, aqui, s� declaro
//ela realmente exite, estou criando-a para enfim, usar o construtor abaixo
	
	private List<ListaModel> listaDeTarefas;
	
	private ListaView listaView;
//no construtor, eu realizo uma atribui��o, lista de tarefas = uma nova ArrayList
	
	public ListaController() {
		listaDeTarefas = new ArrayList<>();
		listaView = new ListaView();
	}
//metodo para adicionar um item a lista
	
	public void adicionartarefa(String lista, String status) {
		ListaModel listaModel = new ListaModel(lista, status);
		
		//acima estou instanciando um objeto
		
		listaDeTarefas.add(listaModel);

	}
//metodo para definir a tarefa como concluida, usando if e else
	
	public void definirTarefaConcluida(int index, boolean concluida) {
		if (index >= 0 && index < listaDeTarefas.size()) {
			ListaModel tarefa = listaDeTarefas.get(index);
			tarefa.setStatus(concluida ? "concluida" : "N�o concluida");
			listaView.mostrarStatusTarefa(tarefa);
		} else {
			listaView.mostrarErro("Indice n�o aceito");
		}
	}
	

}
